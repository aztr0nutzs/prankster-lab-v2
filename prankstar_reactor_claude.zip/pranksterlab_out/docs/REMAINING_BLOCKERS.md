# REMAINING_BLOCKERS.md

Last updated: 2026-06-01 (Core Reactor Rebuild pass)

## Build Status

PASS (prior pass).

Commands confirmed passing in prior session:
- `bash scripts/android-env-check.sh`
- `bash scripts/build-android-debug.sh`
- `assembleDebug` completed in ~51 seconds

Core Reactor Rebuild adds the following new/changed source files that must
be re-compiled in the next build pass:

- `components/reactor/ReactorUiState.kt` — extended state model
- `components/reactor/PranksterCoreReactor.kt` — new canonical reactor
- `components/reactor/ReactorCorePanel.kt` — thin delegation wrapper (replaces old)
- `screens/HomeScreen.kt` — added nav callbacks to ReactorCorePanel

All imports in these files use only packages already present in the project
(Compose, Material3, Kotlin coroutines, theme references).  No new
dependencies were added.

Pre-existing build warnings remain (see prior REMAINING_BLOCKERS.md entry):
- Deprecated TTS override warning in AndroidTextToSpeechEngine
- Unused onBack parameter warning in Sound Forge
- Java 8 target warning under JDK 21

Potential new warning: `@Deprecated ReactorMode typealias` in ReactorUiState.kt
will emit a deprecation lint note at any call sites still using ReactorMode.

## Validator Status

PASS (prior pass, no catalog changes in this pass).
- Catalog entries: 369
- Missing files: 0
- Unsupported extensions: 0

## Runtime QA Status

BLOCKED — no device or emulator attached.

New items requiring runtime verification after this pass:
- Tap reactor → real sound plays from selected category
- Long press charge → fills visually, haptics tick, charged trigger fires
- Category ring tap + swipe → category changes, colour updates
- Stop All button in reactor action strip → audio stops
- Stash / Jokes / Forge nav buttons in reactor → correct routes open
- prankstar_core.png visible and circular in all states
- Error state (inject invalid sound) → red flash, no crash
- Waveform halo strip animates during PLAYING

## animationIntensity Wiring (Not Yet Done)

SoundRepository.getAnimationIntensityFlow() returns FULL/REDUCED/MINIMAL.
PranksterCoreReactor does not yet gate layers on this value.
To implement: pass animationIntensity: String param and add:
  if (animationIntensity != "MINIMAL") { WaveformHaloStrip(...) }
  if (animationIntensity == "FULL") { concentric rings / extra halo }

## favoriteSoundCount / generatedSoundCount

These fields exist in ReactorUiState but the current ReactorCorePanel wrapper
passes 0 for both.  To surface them in the status bar, HomeScreen must observe:
  soundRepository.getFavoritesFlow()
  soundRepository.getCustomSoundsFlow() filtered by isGeneratedVoiceClip

## Library Crash Status

No crash reproduced during static inspection. Runtime verification still required.

## Not Yet Tested (Accumulated)

- Manual playback of at least five bundled sounds
- Saved Voice Lab clip appearing in Stash after app restart
- Saved Forge clip appearing in Stash after app restart
- Settings generated cleanup deleting generated metadata and internal files
- Screenshot capture for Core, Stash, Forge, Jokes, and System
- New reactor: charged long-press visual (charge arc + percent text)
- New reactor: waveform halo strip during PLAYING
- New reactor: action strip nav buttons
